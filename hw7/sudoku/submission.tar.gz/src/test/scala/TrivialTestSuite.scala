class TrivialTestSuite extends org.scalatest.FunSuite {
test ("The solution object must be defined") {
val obj : hw.sudoku.SudokuLike = Solution
}
}